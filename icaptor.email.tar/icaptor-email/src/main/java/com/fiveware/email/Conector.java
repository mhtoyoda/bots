package com.fiveware.email;
/**
 * @author valdisnei
 */
public interface Conector {
    BuilderEmail Email = new EmailMessage();
}
