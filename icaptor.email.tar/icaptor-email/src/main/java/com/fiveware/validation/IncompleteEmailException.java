package com.fiveware.validation;

/**
 * @author valdisnei
 */
public class IncompleteEmailException extends RuntimeException {


	public IncompleteEmailException(String message) {
		super(message);
	}

}
