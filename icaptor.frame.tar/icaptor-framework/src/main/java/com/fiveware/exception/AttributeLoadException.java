package com.fiveware.exception;

public class AttributeLoadException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 7651258898566428229L;

	public AttributeLoadException(String error){
		super(error);
	}
}
