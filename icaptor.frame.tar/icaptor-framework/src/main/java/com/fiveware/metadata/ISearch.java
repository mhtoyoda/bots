package com.fiveware.metadata;

/**
 * Created by valdisnei on 26/06/17.
 */
public interface ISearch {

    Object build();
}
