package com.fiveware.automate;

public class BotAutomationBuilder {

	protected BotAutomationBuilder() {}		
	
	public static BotScreen Web(){
		return new BotScreen();
	}
}
